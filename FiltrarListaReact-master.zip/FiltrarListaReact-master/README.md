# Filtrar Lista on React

browserify jsx/reactApp.jsx > js/build.js -t babelify

with Ecmascript 6
