import React from "react"
import SimpleFilterableList from "./simpleFilterableList.jsx"


React.render(<SimpleFilterableList url="simpleList_data.json"/>,document.getElementById("simpleList"))