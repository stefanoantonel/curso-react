# Pokechat #PlatziReactJS 

## Instrucciones

```
npm install
npm run build
npm start
```

Aquí encontrarás el código que se crea durante el [curso de #PlatziReactJS](https://platzi.com/clases/react-js/) por [Sacha Lifszyc](http://twitter.com/slifszyc).
